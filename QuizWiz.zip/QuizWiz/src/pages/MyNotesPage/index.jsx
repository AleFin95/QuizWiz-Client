import React from 'react'

const MyNotesPage = () => {
  return (
    <h1>MyNotesPage</h1>
  )
}

export default MyNotesPage