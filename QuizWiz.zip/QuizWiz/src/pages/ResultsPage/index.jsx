import React from 'react'

const ResultsPage = () => {
  return (
    <h1>ResultsPage</h1>
  )
}

export default ResultsPage