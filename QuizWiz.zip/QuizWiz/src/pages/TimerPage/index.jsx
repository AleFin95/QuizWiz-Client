import React from 'react'
import { Link } from 'react-router-dom'

const TimerPage = () => {
  return (
    <>
    <h1>TimerPage</h1>
    <p><Link to="/learn/addnotes" >Add your Notes</Link></p>
    </>
  )
}

export default TimerPage