import React from 'react'

const NotFoundPage = () => {
  return (
    <h2>NotFoundPage</h2>
  )
}

export default NotFoundPage